import java.util.ArrayList;
import java.util.Collections;
//import java.util.List;

import model.Card;
import model.Rank;
import model.Suit;

public class Deck {
	ArrayList<Card> cards;

	public Deck() {
		this.newGame();
	}

	public Card deal() {
		return cards.remove((int) (Math.random() * cards.size()));
	}

	public void newGame() {
		cards = new ArrayList<Card>(52);
		for (Suit suit : Suit.values()) {
			for (Rank rank : Rank.values()) {
				cards.add(new Card(rank, suit));
			}
		}
		Collections.shuffle(cards);
	}
}
