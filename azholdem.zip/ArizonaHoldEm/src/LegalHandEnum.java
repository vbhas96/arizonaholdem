
public enum LegalHandEnum {
	isRoyalFlush(10), isStraightFlush(9), is4ofaKind(8), isFullHouse(7), isFlush(6), isStraight(5), is3ofaKind(
			4), is2Pair(3), is1Pair(2), isHighCard(1);
	private int value;

	LegalHandEnum(int val) {
		value = val;
	}

	public int getValue() {
		return this.value;
	}

	public int compare(LegalHandEnum other) {
		return this.getValue() - other.getValue();
	}
}
