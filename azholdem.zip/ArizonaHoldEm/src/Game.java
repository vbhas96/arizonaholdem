/*package tests;

import static org.junit.Assert.*;
import model.Card;
import model.PokerHand;
import model.Rank;
import model.Suit;

import org.junit.Test;*/
import java.util.Scanner;



public class Game {	
	public void testDealer(){
		Scanner sc = new Scanner(System.in);
		System.out.println(
				"Welcome to Arizona Hold 'Em! How many players are playing today? \n Type an integer value between 2-10!");
		int x = Integer.parseInt(sc.nextLine());
		Dealer deal = new Dealer(x);
		System.out.println("Thanks for playing! Come again soon!");
		sc.close();
	}
}
